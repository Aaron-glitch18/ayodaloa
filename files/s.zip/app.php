<?php
//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
if(isset($_POST['envoyer'])) {
    
    if (!empty($_POST['saisie'])) {
        $saisie = htmlspecialchars($_POST['saisie']);
        echo 'La donnée saisie : ' . $saisie;
    } else {
        echo 'Donnée non transmise';
    }
}else {
    echo "Le bouton n'a pas été cliqué";
};
// $arrow_back='<';
$ch = curl_init();
$url="https://api.groq.com/openai/v1/chat/completions";
$apiKey="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";

$systeme_prompt="Tu es un agent intelligent chargé de recueillir les demandes des utilisateurs afin de fournir de les analysés, rechercher les mot clé et trouver leurs besoins
                    en vue de fournir des réponses précises, concises et professionnelles uniquement selon la langue de la demande. Tu n'es basé que sur les données de la ville de Daloa.
                    pour compléter ta réponse et garantir qu’elle soit fiable, à jour et complète. Le format de réponse doit être sans caractères spéciaux superflus.
                    Lorqu'un résultat contient des prix retourne les seulement en franc cfa
                    Précises, Concises, en restant Professionnel.";

curl_setopt($ch, CURLOPT_URL,$url);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Authorization:Bearer '.$apiKey,
    'Content-Type: application/json',
],);
$agent_ia =[
    "model" => "openai/gpt-oss-120b",
    "messages" => [
        [
        "role" => "system",
        "content" =>$systeme_prompt         
        ],
        [
            "role" => "user",
            "content" => $saisie
        ]
    ],
    "max_tokens" => 1300,
    "temperature" => 0.5
];

curl_setopt($ch, CURLOPT_POSTFIELDS,json_encode($agent_ia));

    
$reponse = curl_exec($ch);
$data = json_decode($reponse,true);
$output=htmlspecialchars($data["choices"][0]["message"]["content"]);
    // print_r($output);
    
curl_close($ch);
// header('Location:chat.php');
?>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Actualités - Ville de Daloa</title>

  <!-- Polices Google et icônes Material Symbols -->
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&family=Montserrat:wght@600;700&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1" />
  <link rel="stylesheet" href="style.css">
  <style>
  main{
      padding: 0px;
    }
    .top-header .container {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding-top: 36px;
      padding-bottom: 36px;
    }

    container {
        /*display: flex;*/
        /*flex-direction: column;*/
        /*align-items: center;*/
        justify-content: space-between;
        max-width: var(--max-width);
        margin: auto;
        /*margin-right: auto;*/
        /*padding-left: var(--gutter);*/
        /*padding-right: var(--gutter);*/
        width: 100%;
        padding:36px ;
    }
    #chatAnswer{
        width: var(--max-width);
        height: 500px;
        border: 1px solid brown;
        margin-top: 10px;
        /*margin-bottom: inherit;*/
        margin-bottom: 30px;
    }
    .researchAI{
        height: 15%;
        margin-top: 30px;
    }
    .bot{
        margin:25px 0 0 25px;
        background: white;
        width:fit-content;
        max-width: 400px;
        display: none;
        padding: 10px;
        border-radius: 10px;
        /*min-width: 500px;*/
        word-break: break-word;
    }
    .user{
        width: fit-content;     /* s’adapte au contenu */
        /*max-width: 300px;*/       /* mais ne dépasse pas 300px */
        margin:25px 0 0 25px;
        background: white;
        /*width:300px;*/
        display: none;
        border-radius: 10px;
        padding: 10px;
        max-width: 400px;
        word-break: break-word;
        
        /*padding: 10px;*/
    }

    }
    
    @media (max-width: 768px){
        #chatAnswer{
            width: 100%
        }
    }
  </style>
</head>
<body>

  <!-- TOP HEADER -->
  <header class="top-header">
    <div class="container">
      <p class="logo"><a href="index.php"><</a></p>
      <!--<nav class="nav-links">-->
      <!--  <a href="home.php">Home</a>-->
      <!--  <a href="#" class="active">Actualités</a>-->
      <!--  <a href="#">Établissements</a>-->
      <!--  <a href="#">Business</a>-->
      <!--  <a href="#">Service</a>-->
      <!--</nav>-->
      <div class="header-actions">
        <button aria-label="Rechercher"><span class="material-symbols-outlined">search</span></button>
        <button aria-label="Notifications"><span class="material-symbols-outlined">notifications</span></button>
        <button aria-label="Compte"><span class="material-symbols-outlined">account_circle</span></button>
      </div>
    </div>
  </header>

  <!-- MAIN -->
  <main>
    <div class="container">
        
        <div id="chatAnswer">
            <p class="user"><?php echo $saisie ?></p>
            <p class="bot"><?php echo $output ?></p>

        </div>
        
        <form action="" method="POST">
             <div class="researchAI">
                <textarea name="saisie" id="search" placeholder="Posez vos question et laisser Ayo AI vous répondre..." rows="3" cols="5"></textarea>
                <div id="btnImg">
                    <button type='submit' name='envoyer' id="btn"><img src="image/send1.png"/></button>
                </div>
              </div>
        </form>
    </div>
    
  </main>

  <!-- FOOTER -->
  <!--<footer>-->
  <!--  <div class="container">-->
  <!--    <div class="footer-logo">Ayo Daloa!</div>-->
  <!--    <nav class="footer-links">-->
  <!--      <a href="#">Urgences</a>-->
  <!--      <a href="#">Plan du site</a>-->
  <!--      <a href="#">Mentions Légales</a>-->
  <!--      <a href="#">Contact</a>-->
  <!--    </nav>-->
  <!--    <div class="footer-copy">&copy; 2026 Commune de Daloa. Tous droits réservés.</div>-->
  <!--  </div>-->
  <!--</footer>-->
  <!------------------------------------code js---------------------------------------------->
<!--------------------------------------------------------------------------------------------------------------------------------------------->
  </body>
  <script>
      const chatZone=document.getElementById('chatAnswer');
      const btn=document.getElementById('btn');
      btn.addEventListener('click',()=>{
          
        // let saisie=document.getElementById('search').value;
        let p=document.createElement('p');
        p.innerHTML="<?php echo $saisie;?>";
        p.className='user';
        chatZone.appendChild(p);
        p.style.display='block';
        console.log(saisie);
        //   saisie="";
        let bot=document.createElement('p');
        bot.innerHTML="<?php echo $output; ?>";
        bot.className='bot';
        chatZone.appendChild(bot);
        bot.style.display='block';
      });
      
  </script>


</html>